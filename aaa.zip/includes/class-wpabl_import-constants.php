<?php

class Wpabl_import_Constants {
    
    public function _construct(){
        
        define('WPABL_IMPORT_PLUGIN_ASSETS_PATH', plugin_dir_url( __FILE__ ) . '/assets');
        
        }
    
    }